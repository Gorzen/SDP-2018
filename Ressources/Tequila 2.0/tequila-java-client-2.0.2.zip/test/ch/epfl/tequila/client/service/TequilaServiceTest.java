/**
 * Client for Tequila (federated authentication and access control, http://tequila.epfl.ch)
 * Copyright (C) EPFL
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */
package ch.epfl.tequila.client.service;

import ch.epfl.tequila.client.model.*;
import org.junit.*;

import java.security.*;

/**
 * TestCase for TequilaService
 *
 * @author Laurent Boatto
 */
public class TequilaServiceTest
{
  @Test
  public void createRequest() throws Exception
  {
    ClientConfig config = new ClientConfig();
    config.setHost("test-tequila.epfl.ch");
    config.setOrg("MyOrgLalala");
    config.setService("TotoVaAuZoo");
    config.setRequest("name firstname email title unit office phone username uniqueid unixid groupid where categorie toto");
    config.setAllows("categorie=epfl-guests");
    config.setAuthstrength("2");

    String key = TequilaService.instance().createRequest(config, "http://www.epfl.ch");

    System.out.println("https://" + config.getHost() + "/cgi-bin/tequila/requestauth?requestkey=" + key);
  }

  @Test
  public void validateKey() throws Exception
  {
    ClientConfig config = new ClientConfig();
    config.setHost("test-tequila.epfl.ch");

    String key = "the-key";

    Principal principal = TequilaService.instance().validateKey(config, key);

    Assert.assertNotNull(principal);
  }
}